I chose to not use the EndOfText value because I as unabe to get it to properly render at the end of my string.
The output still worked even without this value.


Part 3)
A) A Sorted list would be in time O(n) because since the list is sorted you can simply iterate over it once and you have your solution
B) An unsorted list would O(n^2) because it would take n * n iterations to find the elements and use them. 
C) A heap would be O(n log n) because it would take n operations to create the first set of binary trees and then log n after that to organize them into their sub trees.
